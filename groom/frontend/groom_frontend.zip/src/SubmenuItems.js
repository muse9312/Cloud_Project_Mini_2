// import Index from "views/Index.js";


import Ananymous from "views/board/Ananymous.js"

// var submenuitems = [
//     {
//         path: "/ananymous",
//         name: "익명게시판",
//         icon: "ni ni-bullet-list-68 text-blue",
//         component: Ananymous,
//         layout: "/admin",
//       }, 
// ]

// export default submenuitems; 

export const submenuitems = [
    {
        path: "/ananymous",
        name: "익명게시판",
        icon: "ni ni-bullet-list-68 text-blue",
        component: Ananymous,
        layout: "/admin",
    },
]

